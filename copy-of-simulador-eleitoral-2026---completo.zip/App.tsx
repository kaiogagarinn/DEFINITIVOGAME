import React, { useState, useEffect, useCallback } from 'react';
import { Activity, BarChart3, Users, Globe, Mic2, Briefcase, Calendar, FileText, ChevronRight, Play, Flag, HelpCircle, X } from 'lucide-react';
import { ROSTER_DATA, ACTIONS_DATA, THEMES } from './constants';
import { Candidate, PlannedAction, TabId, WeekResult, Theme } from './types';
import { formatCurrency, formatSigned, processTurn } from './services/gameLogic';
import { getAvatarFromName } from './services/wikiService';

// Components
import MatrixBackground from './components/MatrixBackground';
import { PlayerChart, AllPollsChart } from './components/Charts';
import { Card, KpiBox, ActionButton, SidebarBtn } from './components/UIComponents';

const START_BUDGET = 20_000_000; // Default for custom creation if needed, though we use roster

export default function App() {
  // -- State --
  const [started, setStarted] = useState(false);
  const [setupIdx, setSetupIdx] = useState(0);
  const [week, setWeek] = useState(1);
  const [currentTheme, setCurrentTheme] = useState<Theme>(THEMES[6]); // Start with 'Semana Morna' usually or random
  
  const [player, setPlayer] = useState<Candidate | null>(null);
  const [rivals, setRivals] = useState<Candidate[]>([]);
  
  const [plannedActions, setPlannedActions] = useState<PlannedAction[]>([]);
  const [weekResults, setWeekResults] = useState<WeekResult[]>([]);
  
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [showReportModal, setShowReportModal] = useState(false);
  const [loadingTurn, setLoadingTurn] = useState(false);

  // -- Initialization --
  const handleStartGame = () => {
    const rawP = ROSTER_DATA[setupIdx];
    // Init avatars
    const hue = (setupIdx * 37) % 360;
    const p: Candidate = {
      ...rawP,
      ...rawP.start,
      hue,
      avatar: getAvatarFromName(rawP.name, hue),
      poll: 1.0, momentum: 0, risk: 0, 
      history: [1.0], lastAgenda: [], lastDeltaPP: 0,
      ongoing: [], alliances: [],
      weekFlags: { debatePrepared:false, primeInterview:false, mediaPush:false }
    };

    // Init rivals
    const otherData = ROSTER_DATA.filter((_, i) => i !== setupIdx)
      .sort(() => 0.5 - Math.random())
      .slice(0, 15); // Pick 15 rivals
    
    const r: Candidate[] = otherData.map((d, i) => {
      const rHue = ((i + 10) * 45) % 360;
      return {
        ...d,
        ...d.start,
        hue: rHue,
        avatar: getAvatarFromName(d.name, rHue),
        poll: Math.random() * 5 + 1, // Random start poll
        momentum: 0, risk: 0,
        history: [], lastAgenda: [], lastDeltaPP: 0,
        ongoing: [], alliances: [],
        weekFlags: { debatePrepared:false, primeInterview:false, mediaPush:false },
        // Adjust start stats slightly for variety
        budget: Math.max(5_000_000, d.start.budget * (0.8 + Math.random()*0.4))
      };
    });

    // Normalize initial polls to sum to 100 roughly
    const totalRaw = p.poll + r.reduce((a,b) => a + b.poll, 0);
    p.poll = (p.poll / totalRaw) * 100;
    p.history = [p.poll];
    r.forEach(riv => {
      riv.poll = (riv.poll / totalRaw) * 100;
      riv.history = [riv.poll];
    });

    setPlayer(p);
    setRivals(r);
    setCurrentTheme(THEMES.find(t => t.id === 'quiet') || THEMES[0]);
    setStarted(true);
  };

  // -- Actions --
  const toggleAction = (type: 'strategy'|'media'|'resources', id: string, cost: number) => {
    if (!player) return;
    
    const existingIdx = plannedActions.findIndex(a => a.type === type && a.id === id);
    if (existingIdx >= 0) {
      // Remove (refund in UI logic only, actual budget touched in turn processing usually, 
      // but let's track 'available' budget visually)
      setPlannedActions(prev => prev.filter((_, i) => i !== existingIdx));
    } else {
      // Add
      if (plannedActions.length >= 2) return alert("Máximo de 2 ações por semana.");
      // Calc current reserved
      const reserved = plannedActions.reduce((acc, pa) => {
         const act = ACTIONS_DATA[pa.type].find(a => a.id === pa.id);
         return acc + (act ? act.cost : 0);
      }, 0);
      
      if (player.budget - reserved < cost) return alert("Orçamento insuficiente.");
      
      setPlannedActions(prev => [...prev, { type, id, targetId: null }]);
    }
  };

  // -- Turn Processing --
  const handleNextTurn = async () => {
    if (!player) return;
    setLoadingTurn(true);

    // Simulate delay for effect
    await new Promise(r => setTimeout(r, 1200));

    const { nextPlayer, nextRivals, weekResult, nextTheme } = processTurn(
      week,
      currentTheme,
      player,
      rivals,
      plannedActions
    );

    setPlayer(nextPlayer);
    setRivals(nextRivals);
    setWeekResults(prev => [weekResult, ...prev]);
    setCurrentTheme(nextTheme);
    setWeek(w => w + 1);
    setPlannedActions([]);
    setLoadingTurn(false);
    setShowReportModal(true);
  };

  // -- Render Helpers --
  if (!started) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex items-center justify-center relative overflow-hidden">
        <MatrixBackground />
        <div className="z-10 max-w-4xl w-full bg-slate-900/90 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row h-[600px]">
          <div className="w-full md:w-1/3 bg-slate-950 border-r border-slate-800 p-6 overflow-y-auto">
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Selecione Candidato</h2>
            <div className="space-y-2">
              {ROSTER_DATA.map((c, i) => (
                <div 
                  key={c.id} 
                  onClick={() => setSetupIdx(i)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all flex items-center gap-3 ${i === setupIdx ? 'bg-blue-900/30 border-blue-500 ring-1 ring-blue-500' : 'bg-slate-900 border-slate-800 hover:border-slate-600'}`}
                >
                  <div className="w-2 h-10 bg-slate-700 rounded-full" /> 
                  <div>
                    <div className="font-bold text-sm text-slate-200">{c.name}</div>
                    <div className="text-[10px] text-slate-500">{c.bloc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex-1 p-8 flex flex-col relative">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Flag size={200} />
            </div>
            <div className="flex-1 z-10">
              <div className="text-slate-400 text-xs font-bold tracking-widest mb-2">SIMULADOR ELEITORAL 2026</div>
              <h1 className="text-3xl font-black text-white mb-1">{ROSTER_DATA[setupIdx].name}</h1>
              <div className="flex gap-2 mb-6">
                <span className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-400 border border-slate-700">{ROSTER_DATA[setupIdx].bloc}</span>
                <span className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-400 border border-slate-700">{ROSTER_DATA[setupIdx].tag}</span>
              </div>
              
              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
                  <div className="text-xs text-slate-500 mb-1">Orçamento Inicial</div>
                  <div className="text-xl font-mono font-bold text-emerald-400">{formatCurrency(ROSTER_DATA[setupIdx].start.budget)}</div>
                </div>
                 <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
                  <div className="text-xs text-slate-500 mb-1">Organização</div>
                  <div className="text-xl font-mono font-bold text-blue-400">{ROSTER_DATA[setupIdx].start.org}</div>
                </div>
                 <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
                  <div className="text-xs text-slate-500 mb-1">Credibilidade</div>
                  <div className="text-xl font-mono font-bold text-amber-400">{ROSTER_DATA[setupIdx].start.cred}</div>
                </div>
              </div>

              <p className="text-slate-400 text-sm leading-relaxed max-w-lg">
                Assuma o comando da campanha. Gerencie recursos, feche alianças, defina estratégias de mídia e prepare-se para debates. 
                <br/><br/>
                Sua missão: Chegar ao segundo turno e conquistar a presidência em um cenário volátil.
              </p>
            </div>
            <button 
              onClick={handleStartGame}
              className="mt-6 w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-lg shadow-blue-900/20 transition-all flex items-center justify-center gap-2"
            >
              INICIAR CAMPANHA <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  const reservedBudget = plannedActions.reduce((acc, pa) => {
      const act = ACTIONS_DATA[pa.type].find(a => a.id === pa.id);
      return acc + (act ? act.cost : 0);
  }, 0);

  return (
    <div className="h-screen bg-slate-950 text-slate-100 font-sans flex flex-col overflow-hidden relative">
      <MatrixBackground />
      
      {/* Top Ticker */}
      <div className="h-7 bg-gradient-to-r from-blue-600 to-indigo-600 flex items-center px-4 gap-4 z-50 text-[10px] font-bold text-white tracking-wider shadow-lg">
        <span className="bg-black/20 px-2 py-0.5 rounded">BRASIL 2026</span>
        <div className="flex-1 overflow-hidden">
          <div className="animate-marquee whitespace-nowrap">
            SEMANA {week} • TEMA: {currentTheme.name.toUpperCase()} • {currentTheme.desc} • INTENÇÃO: {player?.poll.toFixed(2)}% • CAIXA: {formatCurrency(player?.budget || 0)}
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden relative z-10">
        {/* Sidebar */}
        <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col z-20">
          <div className="h-16 flex items-center px-6 border-b border-slate-800 gap-3">
             <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center border border-blue-500/30 text-blue-400">
               <Flag size={16} />
             </div>
             <div>
               <div className="font-black text-xs tracking-wider text-slate-200">SIMULADOR</div>
               <div className="text-[10px] text-slate-500">ELEIÇÕES 2026</div>
             </div>
          </div>

          <div className="flex-1 overflow-y-auto py-4 space-y-1">
            <div className="px-6 text-[10px] font-bold text-slate-600 uppercase mb-2 mt-2">Painel</div>
            <SidebarBtn active={activeTab==='overview'} icon={BarChart3} label="Visão Geral" onClick={()=>setActiveTab('overview')} />
            <SidebarBtn active={activeTab==='strategy'} icon={Briefcase} label="Estratégia & Campo" onClick={()=>setActiveTab('strategy')} />
            <SidebarBtn active={activeTab==='media'} icon={Globe} label="Mídia & Redes" onClick={()=>setActiveTab('media')} />
            <SidebarBtn active={activeTab==='events'} icon={Mic2} label="Debates & Eventos" onClick={()=>setActiveTab('events')} />
            <SidebarBtn active={activeTab==='resources'} icon={Users} label="Recursos & Apoio" onClick={()=>setActiveTab('resources')} />
            <SidebarBtn active={activeTab==='agenda'} icon={Calendar} label="Agenda Semanal" onClick={()=>setActiveTab('agenda')} />
            
            <div className="px-6 text-[10px] font-bold text-slate-600 uppercase mb-2 mt-6">Dados</div>
            <SidebarBtn active={activeTab==='polls'} icon={Activity} label="Pesquisas" onClick={()=>setActiveTab('polls')} />
            <SidebarBtn active={activeTab==='reports'} icon={FileText} label="Histórico" onClick={()=>setActiveTab('reports')} />
          </div>

          <div className="p-4 bg-slate-950 border-t border-slate-800">
            <button 
              onClick={handleNextTurn}
              disabled={loadingTurn}
              className="w-full py-3 bg-red-600 hover:bg-red-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-lg shadow-lg shadow-red-900/20 flex items-center justify-between px-4 transition-all"
            >
              <span>{loadingTurn ? 'PROCESSANDO...' : 'AVANÇAR SEMANA'}</span>
              {!loadingTurn && <ChevronRight size={16} />}
            </button>
            <div className="mt-3 text-[10px] text-slate-500 text-center">
              Confirme suas ações antes de avançar.
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col min-w-0 bg-slate-950/50 backdrop-blur-sm">
          {/* Header Stats */}
          <header className="h-20 bg-slate-900 border-b border-slate-800 flex items-center px-6 justify-between gap-8 shrink-0 overflow-x-auto">
             <div className="flex items-center gap-4 min-w-[200px]">
                <img src={player?.avatar} alt="Avatar" className="w-10 h-10 rounded-lg border border-slate-700 bg-slate-800 object-cover" />
                <div>
                  <div className="font-black text-sm text-white truncate">{player?.name}</div>
                  <div className="text-xs text-slate-500">{player?.bloc}</div>
                </div>
             </div>

             <div className="flex gap-8">
               <KpiBox label="Semana" value={week} />
               <KpiBox label="Caixa Atual" value={formatCurrency(player!.budget - reservedBudget)} color={player!.budget - reservedBudget < 0 ? '#ef4444' : '#10b981'} />
               <KpiBox label="Intenção" value={`${player?.poll.toFixed(2)}%`} />
               <KpiBox label="Org" value={player!.org} color="#60a5fa" />
               <KpiBox label="Eng" value={player!.eng} color="#f59e0b" />
               <KpiBox label="Rejeição" value={`${Math.round(player!.rej)}%`} color="#94a3b8" />
             </div>
          </header>

          <div className="flex-1 overflow-auto p-6">
            
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
                <Card title="Evolução da Campanha" className="h-[300px] md:h-auto">
                  <PlayerChart history={player!.history} hue={player!.hue} />
                </Card>
                <div className="flex flex-col gap-6">
                  <Card title="Planejamento da Semana" subtitle={`${plannedActions.length}/2 ações`} className="flex-1">
                     <div className="space-y-3">
                       {plannedActions.length === 0 ? (
                         <div className="text-sm text-slate-500 text-center py-8">Nenhuma ação planejada. Visite as abas de estratégia.</div>
                       ) : (
                         plannedActions.map((pa, i) => {
                           const act = ACTIONS_DATA[pa.type].find(a => a.id === pa.id);
                           return (
                             <div key={i} className="flex items-center justify-between p-3 bg-slate-800 rounded border border-slate-700">
                               <div>
                                 <div className="font-bold text-sm text-white">{act?.name}</div>
                                 <div className="text-xs text-slate-500 uppercase">{pa.type}</div>
                               </div>
                               <div className="flex items-center gap-3">
                                 <span className="text-xs font-mono text-red-400">-{formatCurrency(act?.cost || 0)}</span>
                                 <button onClick={() => toggleAction(pa.type, pa.id, 0)} className="text-slate-500 hover:text-white"><X size={14} /></button>
                               </div>
                             </div>
                           )
                         })
                       )}
                     </div>
                     <div className="mt-4 p-3 bg-blue-900/10 border border-blue-900/30 rounded text-xs text-blue-300">
                       Tema da Semana: <span className="font-bold text-white">{currentTheme.name}</span>
                       <p className="opacity-70 mt-1">{currentTheme.desc}</p>
                     </div>
                  </Card>
                  <Card title="Log da Campanha" className="h-[200px]">
                    <div className="space-y-1 font-mono text-xs text-slate-400">
                      <div className="text-emerald-500 font-bold">{`> Semana ${week} iniciada.`}</div>
                      {weekResults.length > 0 && <div className="text-slate-300">{`> Último resultado: ${weekResults[0].player.summary}`}</div>}
                      <div>{`> Aguardando ordens...`}</div>
                    </div>
                  </Card>
                </div>
              </div>
            )}

            {(['strategy', 'media', 'resources'] as const).includes(activeTab as any) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                 {ACTIONS_DATA[activeTab].map(act => {
                   const isSelected = plannedActions.some(p => p.type === activeTab && p.id === act.id);
                   return (
                     <ActionButton 
                        key={act.id}
                        title={act.name}
                        desc={act.desc}
                        cost={formatCurrency(act.cost)}
                        selected={isSelected}
                        disabled={!isSelected && (plannedActions.length >= 2 || (player!.budget - reservedBudget) < act.cost)}
                        onClick={() => toggleAction(activeTab as any, act.id, act.cost)}
                     />
                   )
                 })}
              </div>
            )}

            {activeTab === 'polls' && (
              <div className="flex flex-col h-full gap-6">
                 <Card title="Intenção de Voto (Todos)" className="h-[400px]">
                    <AllPollsChart candidates={[player!, ...rivals]} />
                 </Card>
                 <Card title="Ranking Atual">
                    <table className="w-full text-left text-sm text-slate-400">
                      <thead className="bg-slate-900 text-xs uppercase font-bold text-slate-500">
                        <tr>
                          <th className="p-3">#</th>
                          <th className="p-3">Candidato</th>
                          <th className="p-3 text-right">Intenção</th>
                          <th className="p-3 text-right">Rejeição</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {[player!, ...rivals].sort((a,b) => b.poll - a.poll).map((c, i) => (
                          <tr key={c.id} className={c.id === player!.id ? 'bg-blue-900/10' : ''}>
                             <td className="p-3 font-mono font-bold text-slate-600">{i+1}</td>
                             <td className="p-3 flex items-center gap-2">
                               <img src={c.avatar} className="w-6 h-6 rounded bg-slate-800" />
                               <span className={c.id === player!.id ? 'text-white font-bold' : ''}>{c.name}</span>
                             </td>
                             <td className="p-3 text-right font-mono font-bold text-white">{c.poll.toFixed(2)}%</td>
                             <td className="p-3 text-right font-mono text-slate-500">{Math.round(c.rej)}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                 </Card>
              </div>
            )}

            {activeTab === 'events' && (
              <div className="space-y-6">
                <Card title="Eventos Recentes">
                   {weekResults[0]?.events?.length ? weekResults[0].events.map((e, i) => (
                     <div key={i} className="mb-4 p-4 bg-slate-900/50 rounded-lg border border-slate-800">
                        <div className="font-bold text-white text-sm mb-1">{e.title}</div>
                        <div className="text-sm text-slate-400">{e.text}</div>
                     </div>
                   )) : <div className="text-slate-500 text-sm">Nenhum evento principal na última semana.</div>}
                </Card>
              </div>
            )}
            
            {activeTab === 'reports' && (
                <Card title="Histórico de Semanas">
                    <div className="space-y-2">
                        {weekResults.map(r => (
                            <div key={r.week} className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg flex justify-between items-center">
                                <div>
                                    <span className="font-mono text-xs font-bold text-blue-400 mr-3">SEMANA {r.week}</span>
                                    <span className="text-sm font-bold text-slate-200">{r.theme.name}</span>
                                    <div className="text-xs text-slate-500 mt-1">{r.player.summary}</div>
                                </div>
                                <div className={`font-mono font-bold ${r.player.deltaPP >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                    {formatSigned(r.player.deltaPP)} p.p.
                                </div>
                            </div>
                        ))}
                        {weekResults.length === 0 && <div className="text-slate-500 p-4">Sem relatórios disponíveis.</div>}
                    </div>
                </Card>
            )}

            {activeTab === 'agenda' && (
              <Card title="Última Agenda">
                 <div className="space-y-2">
                    {player?.lastAgenda.map((item, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 border-b border-slate-800 last:border-0">
                         <div className={`w-2 h-2 rounded-full ${item.kind === 'action' ? 'bg-blue-500' : item.kind === 'event' ? 'bg-amber-500' : 'bg-slate-600'}`} />
                         <span className="text-sm text-slate-300">{item.text}</span>
                         <span className="ml-auto text-[10px] uppercase font-bold text-slate-600">{item.kind}</span>
                      </div>
                    ))}
                    {(!player?.lastAgenda || player.lastAgenda.length === 0) && <div className="text-slate-500 p-4">Agenda vazia. Avance a semana.</div>}
                 </div>
              </Card>
            )}

          </div>
        </main>
      </div>

      {/* Loading Overlay */}
      {loadingTurn && (
        <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur flex flex-col items-center justify-center">
           <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4" />
           <div className="text-white font-bold tracking-widest animate-pulse">PROCESSANDO SEMANA...</div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && weekResults.length > 0 && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
           <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
              <div className="p-6 border-b border-slate-800 bg-slate-950 flex justify-between items-center">
                 <div>
                    <h2 className="text-xl font-black text-white">RELATÓRIO SEMANA {week - 1}</h2>
                    <div className="text-xs text-slate-500 uppercase tracking-wider mt-1">{weekResults[0].theme.name}</div>
                 </div>
                 <button onClick={() => setShowReportModal(false)} className="text-slate-500 hover:text-white"><X /></button>
              </div>
              <div className="p-8 overflow-y-auto space-y-6">
                 <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-800 p-4 rounded-xl text-center">
                       <div className="text-xs text-slate-500 uppercase">Variação</div>
                       <div className={`text-3xl font-black ${weekResults[0].player.deltaPP >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                         {formatSigned(weekResults[0].player.deltaPP)} pp
                       </div>
                    </div>
                    <div className="bg-slate-800 p-4 rounded-xl text-center">
                       <div className="text-xs text-slate-500 uppercase">Intenção Atual</div>
                       <div className="text-3xl font-black text-white">
                         {weekResults[0].player.pollAfter.toFixed(2)}%
                       </div>
                    </div>
                 </div>

                 <div>
                    <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Manchetes da Semana</h3>
                    <div className="space-y-2">
                       {weekResults[0].headlines.map((h, i) => (
                         <div key={i} className="p-3 bg-slate-950 border border-slate-800 rounded text-sm text-slate-300 italic">
                            "{h}"
                         </div>
                       ))}
                    </div>
                 </div>

                 <div>
                    <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Agenda Realizada</h3>
                    <ul className="list-disc list-inside text-sm text-slate-400 space-y-1">
                       {weekResults[0].player.agenda.slice(0, 5).map((a, i) => <li key={i}>{a}</li>)}
                    </ul>
                 </div>
              </div>
              <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end">
                 <button onClick={() => setShowReportModal(false)} className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg">
                    CONTINUAR
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}