export interface Candidate {
  id: string;
  name: string;
  wikiTitle: string;
  bloc: string;
  tag: string;
  diff: string;
  avatar: string;
  hue: number;
  
  // Stats
  budget: number;
  org: number;
  eng: number;
  cred: number;
  base: number;
  rej: number;
  
  // Dynamic
  poll: number;
  momentum: number;
  risk: number;
  
  history: number[];
  lastAgenda: AgendaItem[];
  lastDeltaPP: number;
  
  // Game logic flags
  ongoing: OngoingEffect[];
  alliances: Alliance[];
  weekFlags: {
    debatePrepared: boolean;
    primeInterview: boolean;
    mediaPush: boolean;
  };
}

export interface AgendaItem {
  text: string;
  kind: 'action' | 'alliance' | 'event' | 'auto';
}

export interface OngoingEffect {
  weeksLeft: number;
  fund?: number;
  burn?: number;
}

export interface Alliance {
  partnerId: string;
  partnerName: string;
  strength: number;
  weeksLeft: number;
  kind: string;
}

export interface ActionDef {
  id: string;
  name: string;
  desc: string;
  cost: number;
  effect: Partial<Stats>;
  requiresTarget?: boolean;
  confirmAgenda?: string[];
  onTheme?: Record<string, Partial<Stats>>;
  special?: string;
  ongoing?: { weeks: number; fund?: number; burn?: number };
}

export interface Stats {
  org: number;
  eng: number;
  cred: number;
  base: number;
  rej: number;
  budget: number;
}

export interface Theme {
  id: string;
  name: string;
  desc: string;
  weight?: Partial<Stats>;
  shock?: { all: Partial<Stats> };
}

export interface PlannedAction {
  type: 'strategy' | 'media' | 'resources';
  id: string;
  targetId: string | null;
}

export interface GameEvent {
  type: string;
  title: string;
  text: string;
  participants?: any[];
}

export interface WeekResult {
  week: number;
  date: string;
  theme: Theme;
  events: GameEvent[];
  headlines: string[];
  allianceChanges: { type: string; text: string }[];
  player: {
    name: string;
    pollBefore: number;
    pollAfter: number;
    deltaPP: number;
    budgetStart: number;
    fund: number;
    burn: number;
    budgetEnd: number;
    confirmedActions: any[];
    agenda: string[];
    summary: string;
  };
  agendaRows: {
    id: string;
    name: string;
    avatar: string;
    bloc: string;
    agenda: string[];
    delta: number;
    pollAfter: number;
    risk: number;
    rej: number;
  }[];
}

export type TabId = 'overview' | 'strategy' | 'media' | 'events' | 'resources' | 'agenda' | 'polls' | 'reports';
