import { Candidate, Theme, ActionDef, PlannedAction, GameEvent, WeekResult, Stats, OngoingEffect, Alliance } from "../types";
import { ACTIONS_DATA, AUTO_AGENDA, THEMES } from "../constants";

// Helpers
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const randFloat = (a: number, b: number) => (Math.random() * (b - a)) + a;

export const formatCurrency = (n: number) => `R$ ${Math.round(n).toLocaleString("pt-BR")}`;
export const formatSigned = (n: number) => (n >= 0 ? "+" : "") + Math.round(n);

// Core Logic
export const allianceStrength = (c: Candidate) => (c.alliances || []).reduce((a, x) => a + (x.strength || 0), 0);

export const computeFixedBurn = (c: Candidate): number => {
  const allies = allianceStrength(c);
  const allyCostFactor = 1 + clamp((allies / 100) * 0.04, 0, 0.06);
  const scale = 1 + (c.poll / 100) * 2.6 + (c.base / 30) * 0.7 + (c.org / 100) * 0.65;
  const base = 1_650_000;
  return Math.floor(base * scale * allyCostFactor);
};

export const computeFundraising = (c: Candidate): number => {
  const allies = allianceStrength(c);
  const allyBoost = 1 + clamp((allies / 100) * 0.06, 0, 0.10);
  const size = 1 + (c.poll / 100) * 2.1 + (c.base / 30) * 0.7;
  const credFactor = (0.55 + (c.cred / 100) * 0.85);
  const mom = 1 + clamp(c.momentum / 6, -0.18, 0.28);
  const rejPenalty = 1 - clamp((c.rej / 100) * 0.25, 0, 0.22);

  let fund = 1_900_000 * size * credFactor * mom * rejPenalty * allyBoost;
  c.ongoing.forEach(e => { if (e.fund) fund += e.fund; });
  return Math.floor(fund);
};

export const scoreForPoll = (c: Candidate, theme: Theme): number => {
  let wOrg = 0.34, wEng = 0.30, wCred = 0.26, wBase = 0.10;
  const tw = theme.weight || {};
  if (tw.org) wOrg += tw.org;
  if (tw.eng) wEng += tw.eng;
  if (tw.cred) wCred += tw.cred;
  if (tw.base) wBase += tw.base;

  const sum = wOrg + wEng + wCred + wBase;
  wOrg /= sum; wEng /= sum; wCred /= sum; wBase /= sum;

  const org = c.org / 100;
  const eng = c.eng / 100;
  const cred = c.cred / 100;
  const base = clamp(c.base / 35, 0, 1);

  const rejPenalty = 1 - clamp((c.rej / 100) * 0.32, 0, 0.26);
  const riskPenalty = 1 - clamp((c.risk / 100) * 0.20, 0, 0.18);
  const momBoost = 1 + clamp(c.momentum / 10, -0.08, 0.12);
  const allyBoost = 1 + clamp((allianceStrength(c) / 100) * 0.08, 0, 0.12);

  const raw = (org * wOrg + eng * wEng + cred * wCred + base * wBase) * rejPenalty * riskPenalty * momBoost * allyBoost;
  return Math.max(0.01, raw);
};

export const applyAction = (target: Candidate, act: ActionDef, theme: Theme, targetId: string | null, candidates: Candidate[]) => {
  const applied: Partial<Stats> = { org: 0, eng: 0, cred: 0, base: 0, rej: 0, budget: 0 };
  
  // Base effects
  const eff = act.effect || {};
  const add = (k: keyof Stats, v: number) => {
    target[k] = (target[k] || 0) + v;
    applied[k] = (applied[k] || 0) + v;
  };

  if (eff.org) add('org', eff.org);
  if (eff.eng) add('eng', eff.eng);
  if (eff.cred) add('cred', eff.cred);
  if (eff.base) add('base', eff.base);
  if (eff.rej) add('rej', eff.rej);
  if (eff.budget) add('budget', eff.budget);

  // Theme bonus
  const key = theme.id;
  const b = act.onTheme?.[key];
  if (b) {
    if (b.org) add('org', b.org);
    if (b.eng) add('eng', b.eng);
    if (b.cred) add('cred', b.cred);
    if (b.base) add('base', b.base);
    if (b.rej) add('rej', b.rej);
    if (b.budget) add('budget', b.budget);
  }

  // Ongoing
  if (act.ongoing) {
    target.ongoing.push({ weeksLeft: act.ongoing.weeks, fund: act.ongoing.fund, burn: act.ongoing.burn });
  }

  // Alliance Special
  let allianceInfo = null;
  if (act.special === "ALLIANCE_NATIONAL" && targetId) {
    const partner = candidates.find(c => c.id === targetId);
    if (partner) {
      allianceInfo = formAlliance(target, partner);
    }
  }

  // Flags
  if (act.special === "DEBATE_PREP") target.weekFlags.debatePrepared = true;
  if (act.special === "PRIME_INTERVIEW") target.weekFlags.primeInterview = true;
  if (act.special === "MEDIA_PUSH") target.weekFlags.mediaPush = true;

  return { applied, allianceInfo, hadThemeBonus: !!b };
};

const formAlliance = (a: Candidate, b: Candidate) => {
   const exists = a.alliances.some(x => x.partnerId === b.id);
   if (exists) return { partnerName: b.name, already: true };

   const blocDistance = (a.bloc === b.bloc) ? 0 : (a.bloc.includes("Centro") || b.bloc.includes("Centro") ? 1 : 2);
   const strength = clamp(Math.round(55 + Math.random() * 30 - blocDistance * 8), 30, 85);
   const weeks = clamp(Math.round(6 + Math.random() * 4 - blocDistance * 1), 4, 8);
   
   const rejHit = blocDistance === 0 ? 0 : (blocDistance === 1 ? 1 : 3);
   a.rej += rejHit;
   b.rej += rejHit;

   const kind = blocDistance === 0 ? "Ideológica" : "Tática";

   a.alliances.push({ partnerId: b.id, partnerName: b.name, strength, weeksLeft: weeks, kind });
   b.alliances.push({ partnerId: a.id, partnerName: a.name, strength, weeksLeft: weeks, kind });

   return { partnerName: b.name, strength, kind, msg: `Coalizão ${kind}: ${a.name} ↔ ${b.name}` };
};

export const aiPlanActions = (c: Candidate, theme: Theme, rivals: Candidate[]): PlannedAction[] => {
  const picks: PlannedAction[] = [];
  const needEng = c.eng < 46;
  const needOrg = c.org < 46;
  const needCred = c.cred < 46;
  const highRej = c.rej > 45;

  // Simple heuristic AI
  if (theme.id === "crisis" && (highRej || needCred) && Math.random() < 0.7) picks.push({ type: 'media', id: 'pr', targetId: null });
  if (c.budget < 10_000_000 && Math.random() < 0.7) picks.push({ type: 'resources', id: 'fund', targetId: null });
  if (needOrg && Math.random() < 0.6) picks.push({ type: 'resources', id: 'vol', targetId: null });
  if (needEng && Math.random() < 0.7) picks.push({ type: 'media', id: 'social', targetId: null });
  if (needCred && Math.random() < 0.55) picks.push({ type: 'strategy', id: 'debprep', targetId: null });
  
  if (c.budget > 18_000_000 && Math.random() < 0.18) {
      const partner = rivals[Math.floor(Math.random()*rivals.length)];
      if(partner && partner.id !== c.id) picks.push({type: 'resources', id: 'coalBig', targetId: partner.id});
  }

  // Fallbacks
  if (picks.length < 2 && Math.random() < 0.5) picks.push({ type: 'strategy', id: 'field', targetId: null });
  
  return picks.slice(0, 2); // Max 2
};

export const generateHeadlines = (theme: Theme, events: GameEvent[]) => {
    // This simulates what would be a generative AI call
    const base = [
      "Redes esquentam com novo assunto da semana",
      "Equipe de campanha ajusta estratégia de comunicação",
      "Bastidores: disputas por apoio e palanques regionais",
      "Tensões e alianças movimentam as conversas políticas"
    ];
    const themeHeadlines: Record<string, string[]> = {
        debate: ["Debate da semana vira trending topic", "Clipes de entrevistas dominam as timelines"],
        economy:["Economia pauta entrevistas e propostas", "Setor produtivo cobra medidas concretas"],
        security:["Segurança pública vira tema central", "Declarações sobre ordem e crime repercutem"],
        health:["Saúde ganha destaque nas conversas", "Programas e promessas são comparados nas redes"],
        climate:["Clima e meio ambiente puxam discussões", "Sustentabilidade vira disputa de narrativa"],
        quiet:["Semana morna: bastidores e articulações", "Campanhas focam em organização e base"],
        crisis:["Crise e ruído impactam reputações", "Notas oficiais tentam conter desgaste"]
    };
    
    const evLines = events.map(e => e.text);
    return [...base, ...(themeHeadlines[theme.id] || []), ...evLines].sort(() => 0.5 - Math.random()).slice(0, 5);
}

export const processTurn = (
  week: number,
  theme: Theme,
  player: Candidate,
  rivals: Candidate[],
  plannedActions: PlannedAction[]
): {
  nextPlayer: Candidate;
  nextRivals: Candidate[];
  weekResult: WeekResult;
  nextTheme: Theme;
} => {
  // 1. Deep clone to avoid mutation side effects during calculation
  // (In a real Redux app we would rely on Immer, but manual spread is okay for this size)
  const allCandidates = [player, ...rivals].map(c => JSON.parse(JSON.stringify(c)) as Candidate);
  const pId = player.id;
  const pRef = allCandidates.find(c => c.id === pId)!;
  const rivalsRef = allCandidates.filter(c => c.id !== pId);
  const oldPolls = new Map(allCandidates.map(c => [c.id, c.poll]));
  
  const allianceChanges: {type: string; text: string}[] = [];
  const events: GameEvent[] = [];
  const confirmedActions: any[] = [];

  // 2. Reset Flags & Costs
  allCandidates.forEach(c => {
    c.weekFlags = { debatePrepared: false, primeInterview: false, mediaPush: false };
    c.lastAgenda = [];
    
    // Ongoing effects
    let extraBurn = 0;
    c.ongoing = c.ongoing.filter(e => {
        if(e.burn) extraBurn += e.burn;
        if(e.fund) c.budget += e.fund;
        e.weeksLeft--;
        return e.weeksLeft > 0;
    });

    const fixed = computeFixedBurn(c);
    c.budget -= (fixed + extraBurn);
    c.budget += computeFundraising(c);
    
    // Auto Agenda
    AUTO_AGENDA.sort(() => 0.5 - Math.random()).slice(0, Math.random() < 0.5 ? 1 : 2).forEach(a => {
        if(a.eff.org) c.org += a.eff.org;
        if(a.eff.eng) c.eng += a.eff.eng;
        c.lastAgenda.push({ text: a.text, kind: 'auto' });
    });
  });

  // 3. Player Actions
  let playerBurn = 0;
  let playerFund = 0;
  // Calculate budget changes for reporting (actual budget was modified above/below)
  const budgetStart = player.budget; // Snapshot before actions but after fixed costs? 
  // Actually, simpler to track just the start of turn budget for the report.
  
  plannedActions.forEach(plan => {
    const act = ACTIONS_DATA[plan.type].find(a => a.id === plan.id);
    if (!act) return;
    // Budget check assumed done at UI level, but apply cost here
    // In the legacy code, cost was 'reserved' in UI. Here we apply it.
    // However, if we want to follow the logic exactly, we subtract cost.
    pRef.budget -= act.cost; 
    
    const res = applyAction(pRef, act, theme, plan.targetId, allCandidates);
    confirmedActions.push({ act, applied: res.applied, hadThemeBonus: res.hadThemeBonus, targetId: plan.targetId });
    
    pRef.lastAgenda.push({ text: act.name, kind: 'action' });
    if(res.allianceInfo) {
        allianceChanges.push({ type: 'formed', text: res.allianceInfo.msg });
        pRef.lastAgenda.push({ text: `Aliança: ${res.allianceInfo.partnerName}`, kind: 'alliance'});
    }
  });

  // 4. AI Rivals Actions
  rivalsRef.forEach(r => {
      const plans = aiPlanActions(r, theme, allCandidates);
      plans.forEach(plan => {
          const act = ACTIONS_DATA[plan.type].find(a => a.id === plan.id);
          if(!act || r.budget < act.cost) return;
          r.budget -= act.cost;
          const res = applyAction(r, act, theme, plan.targetId, allCandidates);
          r.lastAgenda.push({ text: act.name, kind: 'action' });
          if(res.allianceInfo) allianceChanges.push({ type: 'formed', text: res.allianceInfo.msg });
      });
  });

  // 5. Events (Simplified from original)
  if (theme.id === "debate" || Math.random() < 0.15) {
      events.push({ type: "debate", title: "Debate Nacional", text: "Confronto direto entre os principais candidatos." });
      // Apply simple debate effects
      allCandidates.forEach(c => {
         const perf = (c.cred + c.org/2) * (c.weekFlags.debatePrepared ? 1.2 : 1.0) + randFloat(-10, 10);
         if (perf > 80) { c.cred += 3; c.poll += 1; c.lastAgenda.push({text: "Venceu debate", kind: 'event'}); }
         else if (perf < 30) { c.rej += 2; c.poll -= 0.5; c.lastAgenda.push({text: "Mal no debate", kind: 'event'}); }
      });
  }

  // 6. Decay & Theme Shock
  allCandidates.forEach(c => {
      c.eng *= 0.90; // Higher decay than original to force action
      c.org *= 0.98;
      c.cred *= 0.99;
      // Rejection rubber band
      const targetRej = 28 + (c.base > 20 ? 3 : 0);
      c.rej = c.rej + (targetRej - c.rej) * 0.05;
      
      // Theme shock
      if (theme.shock && theme.shock.all) {
          if (theme.shock.all.cred) c.cred += theme.shock.all.cred;
          if (theme.shock.all.rej) c.rej += theme.shock.all.rej;
      }
      
      // Clamps
      c.org = clamp(c.org, 5, 100);
      c.eng = clamp(c.eng, 5, 100);
      c.cred = clamp(c.cred, 5, 100);
      c.rej = clamp(c.rej, 5, 80);
      c.base = clamp(c.base, 3, 40);
  });

  // 7. Recalc Polls
  const scores = allCandidates.map(c => scoreForPoll(c, theme));
  const totalScore = scores.reduce((a, b) => a + b, 0);
  allCandidates.forEach((c, i) => {
      const nextPoll = (scores[i] / totalScore) * 100;
      const delta = nextPoll - (oldPolls.get(c.id) || 0);
      c.lastDeltaPP = delta;
      c.momentum = 0.6 * c.momentum + 0.4 * delta;
      c.poll = nextPoll;
      c.history.push(nextPoll);
  });

  // 8. Ticking Alliances
  allCandidates.forEach(c => {
      c.alliances = c.alliances.filter(a => {
          a.weeksLeft--;
          if (a.weeksLeft <= 0 && c.id === pId) allianceChanges.push({ type: 'ended', text: `Aliança com ${a.partnerName} terminou.`});
          return a.weeksLeft > 0;
      });
  });

  // 9. Reporting
  const nextPlayer = allCandidates.find(c => c.id === pId)!;
  const nextRivals = allCandidates.filter(c => c.id !== pId);

  const headlines = generateHeadlines(theme, events);
  
  const weekResult: WeekResult = {
      week,
      date: new Date().toISOString(), // In real app use game date
      theme,
      events,
      headlines,
      allianceChanges,
      player: {
          name: nextPlayer.name,
          pollBefore: oldPolls.get(pId) || 0,
          pollAfter: nextPlayer.poll,
          deltaPP: nextPlayer.lastDeltaPP,
          budgetStart: budgetStart,
          fund: playerFund, // simplified
          burn: playerBurn, // simplified
          budgetEnd: nextPlayer.budget,
          confirmedActions,
          agenda: nextPlayer.lastAgenda.map(a => a.text),
          summary: nextPlayer.lastDeltaPP > 0.1 ? "Semana Positiva" : (nextPlayer.lastDeltaPP < -0.1 ? "Semana Negativa" : "Semana Estável")
      },
      agendaRows: allCandidates.map(c => ({
          id: c.id,
          name: c.name,
          avatar: c.avatar,
          bloc: c.bloc,
          agenda: c.lastAgenda.map(a => a.text),
          delta: c.lastDeltaPP,
          pollAfter: c.poll,
          risk: c.risk,
          rej: c.rej
      }))
  };

  const nextTheme = THEMES[Math.floor(Math.random() * THEMES.length)];

  return { nextPlayer, nextRivals, weekResult, nextTheme };
};
