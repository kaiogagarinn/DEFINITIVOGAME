import { Candidate } from "../types";

const WIKI_API = "https://pt.wikipedia.org/w/api.php";

export const getAvatarFromName = (name: string, hue: number): string => {
  const parts = name.replace(/\s+/g,' ').trim().split(' ');
  const ini = (parts.length === 1) 
    ? parts[0].slice(0,2).toUpperCase() 
    : (parts[0][0] + parts[parts.length-1][0]).toUpperCase();
    
  // Using a data URI for fallback
  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" width="128" height="128">
    <defs>
      <linearGradient id="g" x1="0" x2="1" y1="0" y2="1">
        <stop offset="0" stop-color="hsl(${hue},80%,55%)"/>
        <stop offset="1" stop-color="hsl(${(hue+35)%360},80%,45%)"/>
      </linearGradient>
    </defs>
    <rect x="0" y="0" width="128" height="128" fill="url(#g)"/>
    <text x="64" y="78" text-anchor="middle"
      font-size="48" font-family="Arial, sans-serif" font-weight="bold" fill="#ffffff">${ini}</text>
  </svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

export const fetchWikiImage = async (title: string): Promise<string | null> => {
  try {
    const params = new URLSearchParams({
      action: "query",
      format: "json",
      formatversion: "2",
      prop: "pageimages",
      piprop: "thumbnail",
      pithumbsize: "200",
      pilicense: "free",
      titles: title,
      origin: "*"
    });

    const res = await fetch(`${WIKI_API}?${params.toString()}`);
    const json = await res.json();
    const page = json?.query?.pages?.[0];
    return page?.thumbnail?.source || null;
  } catch (e) {
    console.error("Wiki fetch error", e);
    return null;
  }
};
