import React from 'react';
import { Area, AreaChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Candidate } from '../types';

interface PlayerChartProps {
  history: number[];
  hue: number;
}

export const PlayerChart: React.FC<PlayerChartProps> = ({ history, hue }) => {
  const data = history.map((val, i) => ({ w: `W${i + 1}`, val }));

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data}>
        <defs>
          <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={`hsl(${hue}, 80%, 55%)`} stopOpacity={0.3} />
            <stop offset="95%" stopColor={`hsl(${hue}, 80%, 55%)`} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
        <XAxis dataKey="w" hide />
        <YAxis domain={[0, 'auto']} hide />
        <Tooltip 
          contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
          itemStyle={{ color: `hsl(${hue}, 80%, 70%)` }}
        />
        <Area 
          type="monotone" 
          dataKey="val" 
          stroke={`hsl(${hue}, 80%, 55%)`} 
          fillOpacity={1} 
          fill="url(#colorVal)" 
        />
      </AreaChart>
    </ResponsiveContainer>
  );
};

interface AllPollsChartProps {
  candidates: Candidate[];
}

export const AllPollsChart: React.FC<AllPollsChartProps> = ({ candidates }) => {
  // Transform data: [{ w: 'W1', CAND_ID: 23.5, ... }]
  const maxLength = Math.max(...candidates.map(c => c.history.length));
  const data = Array.from({ length: maxLength }, (_, i) => {
    const row: any = { name: `W${i + 1}` };
    candidates.forEach(c => {
      row[c.id] = c.history[i] ?? 0;
    });
    return row;
  });

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
        <XAxis dataKey="name" stroke="#64748b" style={{ fontSize: '10px' }} />
        <YAxis stroke="#64748b" style={{ fontSize: '10px' }} domain={[0, 40]} />
        <Tooltip 
          contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px' }} 
        />
        {candidates.map((c) => (
          <Line
            key={c.id}
            type="monotone"
            dataKey={c.id}
            name={c.name}
            stroke={`hsl(${c.hue}, 80%, 60%)`}
            strokeWidth={c.id === 'PLAYER' || c.history[c.history.length-1] > 15 ? 3 : 1}
            opacity={c.history[c.history.length-1] < 2 ? 0.3 : 1}
            dot={false}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
};
