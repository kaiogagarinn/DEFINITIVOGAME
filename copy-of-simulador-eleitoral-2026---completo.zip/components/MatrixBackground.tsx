import React, { useEffect, useRef } from 'react';

const MatrixBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cvs = canvasRef.current;
    if (!cvs) return;
    const ctx = cvs.getContext('2d');
    if (!ctx) return;

    let w = cvs.width = window.innerWidth;
    let h = cvs.height = window.innerHeight;
    const cols = Math.floor(w / 20);
    const ypos = Array(cols).fill(0);

    const resize = () => {
      w = cvs.width = window.innerWidth;
      h = cvs.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);

    const interval = setInterval(() => {
      ctx.fillStyle = '#0001';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#10b981'; // Tailwind emerald-500
      ctx.font = '12px monospace';
      
      ypos.forEach((y, i) => {
        const text = String.fromCharCode(33 + Math.random() * 90);
        const x = i * 20;
        ctx.fillText(text, x, y);
        if (y > 100 + Math.random() * 10000) ypos[i] = 0;
        else ypos[i] = y + 20;
      });
    }, 50);

    return () => {
      clearInterval(interval);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 opacity-[0.03] pointer-events-none" />;
};

export default MatrixBackground;
