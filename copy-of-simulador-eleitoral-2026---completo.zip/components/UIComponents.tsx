import React from 'react';
import { LucideIcon } from 'lucide-react';

export const Card: React.FC<{ title: string; subtitle?: string; children: React.ReactNode; className?: string }> = ({ title, subtitle, children, className }) => (
  <div className={`bg-slate-800 border border-slate-700 rounded-xl overflow-hidden shadow-lg flex flex-col ${className}`}>
    <div className="bg-slate-900/40 px-4 py-3 border-b border-slate-700 flex justify-between items-center">
      <span className="font-bold text-xs uppercase tracking-wider text-slate-400">{title}</span>
      {subtitle && <span className="font-mono text-[10px] text-slate-500">{subtitle}</span>}
    </div>
    <div className="p-4 flex-1 overflow-auto">
      {children}
    </div>
  </div>
);

export const KpiBox: React.FC<{ label: string; value: string | number; color?: string; help?: string }> = ({ label, value, color, help }) => (
  <div className="flex flex-col min-w-[100px]">
    <div className="flex items-center gap-1 justify-end text-[10px] font-bold uppercase text-slate-500">
      {label}
    </div>
    <div className="text-right font-mono font-bold text-lg mt-1" style={{ color: color || '#f1f5f9' }}>
      {value}
    </div>
  </div>
);

export const ActionButton: React.FC<{ 
  title: string; 
  desc: string; 
  cost: string; 
  onClick: () => void; 
  disabled?: boolean;
  selected?: boolean;
}> = ({ title, desc, cost, onClick, disabled, selected }) => (
  <button 
    onClick={onClick}
    disabled={disabled}
    className={`
      flex flex-col p-4 rounded-xl border text-left transition-all h-full
      ${selected ? 'bg-blue-900/20 border-blue-500 ring-1 ring-blue-500' : 'bg-slate-800 border-slate-700 hover:bg-slate-700 hover:border-blue-400'}
      ${disabled ? 'opacity-50 cursor-not-allowed grayscale' : 'cursor-pointer'}
    `}
  >
    <span className="font-bold text-slate-100 text-sm mb-1 block">{title}</span>
    <span className="text-xs text-slate-400 leading-snug mb-3 flex-1">{desc}</span>
    <span className="inline-flex items-center gap-1 bg-amber-500/10 text-amber-500 text-[10px] font-mono font-bold px-2 py-1 rounded-full self-start">
      {cost}
    </span>
  </button>
);

export const SidebarBtn: React.FC<{ active: boolean; icon: LucideIcon; label: string; onClick: () => void }> = ({ active, icon: Icon, label, onClick }) => (
  <button 
    onClick={onClick}
    className={`
      w-full flex items-center gap-3 px-4 py-3 text-sm font-bold transition-all border-l-4
      ${active ? 'bg-blue-500/10 text-white border-blue-500' : 'text-slate-400 border-transparent hover:bg-slate-800 hover:text-white'}
    `}
  >
    <Icon size={18} />
    {label}
  </button>
);
