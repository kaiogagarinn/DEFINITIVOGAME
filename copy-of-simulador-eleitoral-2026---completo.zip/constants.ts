import { ActionDef, Theme } from "./types";

export const ROSTER_DATA = [
  { id:"LULA", name:"Luiz Inácio Lula da Silva", wikiTitle:"Luiz Inácio Lula da Silva", bloc:"Centro-esquerda", tag:"Incumbência", diff:"Médio",  start:{budget:120_000_000, org:74, eng:62, cred:66, base:30, rej:34} },
  { id:"FLAVIO", name:"Flávio Bolsonaro", wikiTitle:"Flávio Bolsonaro", bloc:"Direita", tag:"Herança política", diff:"Médio", start:{budget:95_000_000, org:62, eng:70, cred:48, base:26, rej:42} },
  { id:"TARCISIO", name:"Tarcísio de Freitas", wikiTitle:"Tarcísio de Freitas", bloc:"Direita", tag:"Executivo", diff:"Difícil", start:{budget:70_000_000, org:68, eng:52, cred:55, base:20, rej:36} },
  { id:"ZEMA", name:"Romeu Zema", wikiTitle:"Romeu Zema", bloc:"Centro-direita", tag:"Gestão", diff:"Difícil", start:{budget:55_000_000, org:58, eng:48, cred:52, base:16, rej:33} },
  { id:"HADDAD", name:"Fernando Haddad", wikiTitle:"Fernando Haddad", bloc:"Centro-esquerda", tag:"Técnico", diff:"Difícil", start:{budget:60_000_000, org:60, eng:44, cred:58, base:18, rej:35} },
  { id:"TEBET", name:"Simone Tebet", wikiTitle:"Simone Tebet", bloc:"Centro", tag:"Coalizão", diff:"Difícil", start:{budget:45_000_000, org:52, eng:40, cred:58, base:12, rej:28} },
  { id:"CIRO", name:"Ciro Gomes", wikiTitle:"Ciro Gomes", bloc:"Centro-esquerda", tag:"Oratória", diff:"Difícil", start:{budget:40_000_000, org:46, eng:54, cred:46, base:12, rej:40} },
  { id:"MARINA", name:"Marina Silva", wikiTitle:"Marina Silva", bloc:"Centro-esquerda", tag:"Sustent.", diff:"Difícil", start:{budget:35_000_000, org:42, eng:44, cred:60, base:10, rej:25} },
  { id:"BOULOS", name:"Guilherme Boulos", wikiTitle:"Guilherme Boulos", bloc:"Esquerda", tag:"Mobilização", diff:"Difícil", start:{budget:28_000_000, org:44, eng:62, cred:42, base:9, rej:44} },
  { id:"EDULEITE", name:"Eduardo Leite", wikiTitle:"Eduardo Leite", bloc:"Centro", tag:"Renovação", diff:"Difícil", start:{budget:30_000_000, org:48, eng:40, cred:52, base:9, rej:30} },
  { id:"ALCKMIN", name:"Geraldo Alckmin", wikiTitle:"Geraldo Alckmin", bloc:"Centro", tag:"Articulação", diff:"Difícil", start:{budget:38_000_000, org:56, eng:34, cred:58, base:10, rej:27} },
  { id:"CAIADO", name:"Ronaldo Caiado", wikiTitle:"Ronaldo Caiado", bloc:"Centro-direita", tag:"Segurança", diff:"Difícil", start:{budget:34_000_000, org:52, eng:40, cred:50, base:10, rej:32} },
  { id:"DINO", name:"Flávio Dino", wikiTitle:"Flávio Dino", bloc:"Centro-esquerda", tag:"Institucional", diff:"Difícil", start:{budget:32_000_000, org:50, eng:38, cred:56, base:9, rej:29} },
  { id:"TABATA", name:"Tabata Amaral", wikiTitle:"Tabata Amaral", bloc:"Centro", tag:"Programática", diff:"Difícil", start:{budget:22_000_000, org:38, eng:46, cred:52, base:7, rej:26} },
  { id:"KIM", name:"Kim Kataguiri", wikiTitle:"Kim Kataguiri", bloc:"Centro-direita", tag:"Digital", diff:"Difícil", start:{budget:18_000_000, org:34, eng:56, cred:38, base:6, rej:41} },
  { id:"MORO", name:"Sergio Moro", wikiTitle:"Sergio Moro", bloc:"Direita", tag:"Lei & Ordem", diff:"Difícil", start:{budget:26_000_000, org:42, eng:44, cred:44, base:8, rej:39} },
  { id:"JANAINA", name:"Janaína Paschoal", wikiTitle:"Janaína Paschoal", bloc:"Direita", tag:"Opinião", diff:"Difícil", start:{budget:14_000_000, org:30, eng:50, cred:38, base:5, rej:43} },
  { id:"MANDETTA", name:"Luiz Henrique Mandetta", wikiTitle:"Luiz Henrique Mandetta", bloc:"Centro", tag:"Saúde", diff:"Difícil", start:{budget:16_000_000, org:36, eng:36, cred:50, base:6, rej:31} },
  { id:"DORIA", name:"João Doria", wikiTitle:"João Doria", bloc:"Centro-direita", tag:"Marketing", diff:"Difícil", start:{budget:24_000_000, org:40, eng:44, cred:40, base:7, rej:38} },
  { id:"HUCK", name:"Luciano Huck", wikiTitle:"Luciano Huck", bloc:"Centro", tag:"Outsider", diff:"Difícil", start:{budget:20_000_000, org:28, eng:52, cred:42, base:6, rej:34} }
];

export const THEMES: Theme[] = [
  { id:"debate",  name:"Debates & Confrontos", desc:"Debates dominam o noticiário: credibilidade e preparo pesam mais.", weight:{cred:+0.10, eng:-0.03} },
  { id:"economy", name:"Economia", desc:"Economia vira centro do debate: propostas e credibilidade valem muito.", weight:{cred:+0.08, org:+0.04} },
  { id:"security",name:"Segurança Pública", desc:"Segurança e ordem entram nos trends: base e cred ajudam a crescer.", weight:{base:+0.06, cred:+0.05} },
  { id:"health",  name:"Saúde & Bem-estar", desc:"Saúde ganha espaço: credibilidade e organização fazem diferença.", weight:{cred:+0.06, org:+0.04} },
  { id:"climate", name:"Clima & Meio Ambiente", desc:"Clima vira assunto: engajamento sobe se houver proposta e coerência.", weight:{eng:+0.06, cred:+0.04} },
  { id:"quiet",   name:"Semana Morna", desc:"Poucas novidades: quem tem máquina organizada avança no silêncio.", weight:{org:+0.06} },
  { id:"crisis",  name:"Crise & Ruído", desc:"Crises e ruídos: rejeição e credibilidade definem sobrevivência.", weight:{cred:+0.10}, shock:{ all:{cred:-4, eng:-2, rej:+2} } }
];

export const ACTIONS_DATA: Record<string, ActionDef[]> = {
  strategy: [
    { id:'field', name:'Mutirão de base', desc:'Fortalece máquina e base local. Crescimento consistente.', cost:3_000_000,
      effect:{org:+6, base:+1, eng:+2, rej:-1}, confirmAgenda:["Mutirão em bairros estratégicos","Reunião com lideranças comunitárias"], onTheme:{quiet:{org:+2}}
    },
    { id:'data', name:'Pesquisa & Dados', desc:'Ajusta mensagens por perfil. Melhora eficiência de mídia.', cost:4_200_000,
      effect:{org:+5, cred:+2}, confirmAgenda:["Reunião com equipe de dados","Ajuste de narrativa por segmento"], onTheme:{economy:{cred:+1}}
    },
    { id:'debprep', name:'Treino de debate', desc:'Ganha credibilidade e reduz dano em tema “Debates”.', cost:2_400_000,
      effect:{cred:+7, rej:-1}, confirmAgenda:["Treino de debate com especialistas","Simulação de entrevistas"], onTheme:{debate:{cred:+3}},
      special:"DEBATE_PREP"
    },
    { id:'coal', name:'Costura de apoios', desc:'Aumenta base e reduz risco. Cresce com consistência.', cost:5_500_000,
      effect:{base:+2, cred:+3, org:+2, rej:-1}, confirmAgenda:["Encontro com lideranças regionais","Anúncio de apoio local"], onTheme:{quiet:{base:+1}}
    },
    { id:'policy', name:'Pacote programático', desc:'Aumenta credibilidade; rende bônus se o tema encaixar.', cost:1_800_000,
      effect:{cred:+6, eng:+1, rej:-1}, confirmAgenda:["Apresentação de propostas","Coletiva com técnicos"], onTheme:{economy:{cred:+2}, health:{cred:+2}, climate:{cred:+2}}
    },
    { id:'townhall', name:'Encontro aberto', desc:'Boa forma de reduzir rejeição e elevar credibilidade.', cost:2_200_000,
      effect:{cred:+3, eng:+3, rej:-3}, confirmAgenda:["Encontro aberto com perguntas do público"], onTheme:{crisis:{rej:-2}}
    }
  ],
  media: [
    { id:'social', name:'Conteúdo diário', desc:'Sobe engajamento rápido, mas precisa consistência.', cost:1_200_000,
      effect:{eng:+10, org:+1}, confirmAgenda:["Lives curtas + cortes","Posts segmentados ao longo da semana"], onTheme:{climate:{eng:+2}},
      special:"MEDIA_PUSH"
    },
    { id:'tv', name:'TV/Rádio (bloco)', desc:'Alcance alto, caro. Ajuda a converter quando org está alta.', cost:6_000_000,
      effect:{eng:+12, cred:+2}, confirmAgenda:["Gravação de programa","Entrevista em rádio"], onTheme:{economy:{cred:+1}},
      special:"MEDIA_PUSH"
    },
    { id:'influ', name:'Parcerias Creators', desc:'Engajamento forte. Pode aumentar rejeição se soar artificial.', cost:3_600_000,
      effect:{eng:+14, cred:+1, rej:+1}, confirmAgenda:["Colab com criadores","Reação a tendências"], onTheme:{quiet:{eng:+1}},
      special:"MEDIA_PUSH"
    },
    { id:'caravan', name:'Caravana regional', desc:'Boa para base e engajamento. Exige logística.', cost:4_800_000,
      effect:{base:+2, eng:+8, org:+1}, confirmAgenda:["Caravana por cidades-chave","Comício regional"], onTheme:{security:{base:+1}}
    },
    { id:'pr', name:'Gestão de crise & PR', desc:'Reduz rejeição e amortece semanas turbulentas.', cost:2_700_000,
      effect:{cred:+4, rej:-6}, confirmAgenda:["Reunião com equipe de comunicação","Nota pública + alinhamento"], onTheme:{crisis:{cred:+2, rej:-2}}
    },
    { id:'debateShow', name:'Entrevista Prime', desc:'Ajuda credibilidade e engajamento; risco se cred baixa.', cost:3_200_000,
      effect:{eng:+6, cred:+4, rej:+1}, confirmAgenda:["Entrevista em horário nobre"], onTheme:{debate:{cred:+2}},
      special:"PRIME_INTERVIEW"
    }
  ],
  resources: [
    { id:'fund', name:'Jantar de captação', desc:'Melhora caixa e um pouco a credibilidade.', cost:900_000,
      effect:{budget:+4_500_000, cred:+1}, confirmAgenda:["Jantar de arrecadação com apoiadores"], onTheme:{economy:{budget:+600_000}}
    },
    { id:'don', name:'Doação recorrente', desc:'Aumenta captação por 4 semanas (efeito contínuo).', cost:1_100_000,
      effect:{}, ongoing:{weeks:4, fund:+1_200_000, burn:+120_000}, confirmAgenda:["Campanha de doação recorrente lançada"], onTheme:{quiet:{budget:+200_000}}
    },
    { id:'vol', name:'Mobilizar voluntários', desc:'Aumenta organização com baixo custo.', cost:1_400_000,
      effect:{org:+4, eng:+2, rej:-1}, confirmAgenda:["Treinamento de voluntários","Ação coordenada de rua"], onTheme:{quiet:{org:+1}}
    },
    { id:'coalBig', name:'Aliança nacional', desc:'Negociação de aliança. Aumenta capilaridade.', cost:4_900_000,
      effect:{cred:+2}, confirmAgenda:["Reunião de negociação de aliança","Anúncio de coalizão"], onTheme:{crisis:{cred:+1}},
      requiresTarget:true,
      special:"ALLIANCE_NATIONAL"
    }
  ]
};

export const AUTO_AGENDA = [
  { text:"Entrevista local", eff:{eng:+2, cred:+1} },
  { text:"Visita a região estratégica", eff:{base:+1, eng:+1} },
  { text:"Reunião com equipe", eff:{org:+2} },
  { text:"Evento de apoiadores", eff:{budget:+600_000, cred:+1} },
  { text:"Pronunciamento nas redes", eff:{eng:+2, rej:+1} },
  { text:"Bastidores (sem holofote)", eff:{org:+1, cred:+1, rej:-1} }
];